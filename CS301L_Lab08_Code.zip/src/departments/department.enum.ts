export enum Department {
  ComputerScience = 'Computer Science',
  SoftwareEngineering = 'Software Engineering',
  DataScience = 'Data Science',
  ElectricalEngineering = 'Electrical Engineering',
  Mathematics = 'Mathematics',
}
