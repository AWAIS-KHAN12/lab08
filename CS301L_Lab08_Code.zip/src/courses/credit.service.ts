import { Course } from './course.entity';

export class CreditService {
  totalCredits(courses: Course[]): number {
    return courses.reduce((total, course) => total + Number(course.creditHours), 0);
  }

  isOverloaded(totalCredits: number): boolean {
    return totalCredits > 18;
  }
}
