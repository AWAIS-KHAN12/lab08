import { Test } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import * as request from 'supertest';
import { AppModule } from '../src/app.module';
import { createValidationPipe } from '../src/common/validation';
import { COURSE_STORE, InMemoryCourseStore } from '../src/courses/store/course-store';

describe('Lab 08 API (e2e)', () => {
  let app: INestApplication;

  beforeAll(async () => {
    const moduleBuilder = Test.createTestingModule({ imports: [AppModule] });
    moduleBuilder.overrideProvider(COURSE_STORE).useValue(new InMemoryCourseStore([
      { code: 'CS-301', title: 'Full Stack Web Development', creditHours: 3, instructor: 'Dr. Hamza Rauf', department: 'Computer Science' as any },
    ]));
    const moduleFixture = await moduleBuilder.compile();
    app = moduleFixture.createNestApplication();
    app.setGlobalPrefix('api');
    app.useGlobalPipes(createValidationPipe());
    await app.init();
  });

  afterAll(async () => app.close());

  it('returns course list', async () => {
    const response = await request(app.getHttpServer()).get('/api/courses').expect(200);
    expect(Array.isArray(response.body)).toBe(true);
  });

  it('returns course statistics', async () => {
    const response = await request(app.getHttpServer()).get('/api/courses/stats').expect(200);
    expect(response.body.totalCourses).toBe(1);
    expect(response.body.totalCredits).toBe(3);
  });

  it('returns an existing course', async () => {
    const response = await request(app.getHttpServer()).get('/api/courses/CS-301').expect(200);
    expect(response.body.title).toBe('Full Stack Web Development');
  });

  it('returns 400 for invalid code format', async () => {
    await request(app.getHttpServer()).get('/api/courses/abc').expect(400);
  });

  it('returns 400 for invalid query sort', async () => {
    await request(app.getHttpServer()).get('/api/courses?sort=title').expect(400);
  });

  it('returns 400 when fee creditHours is missing', async () => {
    await request(app.getHttpServer()).get('/api/fees/BSCS-023').expect(400);
  });

  it('returns fee information', async () => {
    const response = await request(app.getHttpServer()).get('/api/fees/info').expect(200);
    expect(response.body.policy).toBeDefined();
    expect(response.body.ratePerCreditHour).toBe(5000);
  });
});
