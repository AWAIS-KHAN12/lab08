import { InMemoryCourseStore } from './course-store';

describe('InMemoryCourseStore', () => {
  it('reads and writes courses', () => {
    const store = new InMemoryCourseStore([]);
    store.writeAll([{ code: 'CS-301', title: 'Web', creditHours: 3, instructor: 'Dr. A', department: 'Computer Science' as any }]);
    expect(store.readAll()).toHaveLength(1);
  });
});
