import { Module } from '@nestjs/common';
import { CommonModule } from './common/common.module';
import { StudentsModule } from './students/students.module';
import { CoursesModule } from './courses/courses.module';
import { FeesModule } from './fees/fees.module';

@Module({
  imports: [CommonModule, StudentsModule, CoursesModule, FeesModule],
})
export class AppModule {}
