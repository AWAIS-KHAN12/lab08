export interface FeePolicy {
  readonly name: string;
  calculate(creditHours: number, cgpa: number, ratePerCreditHour: number): number;
}

export const FEE_POLICY = Symbol('FEE_POLICY');
export const FEE_RATE = 'FEE_RATE';

export class StandardFeePolicy implements FeePolicy {
  readonly name = 'standard';

  calculate(creditHours: number, cgpa: number, ratePerCreditHour: number): number {
    return creditHours * ratePerCreditHour;
  }
}

export class MeritFeePolicy implements FeePolicy {
  readonly name = 'merit';

  calculate(creditHours: number, cgpa: number, ratePerCreditHour: number): number {
    const standardTotal = creditHours * ratePerCreditHour;
    if (cgpa >= 3.5) return standardTotal * 0.5;
    if (cgpa >= 3.0) return standardTotal * 0.75;
    return standardTotal;
  }
}
