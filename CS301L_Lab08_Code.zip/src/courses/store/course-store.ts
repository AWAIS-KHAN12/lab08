import * as fs from 'fs';
import * as path from 'path';
import { Course } from '../course.entity';

export const COURSE_STORE = Symbol('COURSE_STORE');

export interface CourseStore {
  readAll(): Course[];
  writeAll(courses: Course[]): void;
}

export class InMemoryCourseStore implements CourseStore {
  private courses: Course[];

  constructor(initialCourses: Course[] = []) {
    this.courses = initialCourses.map((course) => ({ ...course }));
  }

  readAll(): Course[] {
    return this.courses.map((course) => ({ ...course }));
  }

  writeAll(courses: Course[]): void {
    this.courses = courses.map((course) => ({ ...course }));
  }
}

export class JsonFileCourseStore implements CourseStore {
  constructor(private readonly filePath = path.join(process.cwd(), 'src/courses/data/courses.json')) {}

  readAll(): Course[] {
    try {
      if (!fs.existsSync(this.filePath)) return [];
      return JSON.parse(fs.readFileSync(this.filePath, 'utf8'));
    } catch (error) {
      throw new Error(`Could not read courses file: ${error.message}`);
    }
  }

  writeAll(courses: Course[]): void {
    try {
      fs.mkdirSync(path.dirname(this.filePath), { recursive: true });
      fs.writeFileSync(this.filePath, JSON.stringify(courses, null, 2) + '\n');
    } catch (error) {
      throw new Error(`Could not write courses file: ${error.message}`);
    }
  }
}
