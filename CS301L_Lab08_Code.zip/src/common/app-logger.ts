import { Injectable } from '@nestjs/common';
import * as fs from 'fs';
import * as path from 'path';

@Injectable()
export class AppLogger {
  log(message: string) {
    const line = `[${new Date().toISOString()}] ${message}`;
    console.log(line);

    if (process.env.LOG_TO_FILE === 'true') {
      const directory = path.join(process.cwd(), 'logs');
      fs.mkdirSync(directory, { recursive: true });
      fs.appendFileSync(path.join(directory, 'app.log'), line + '\n');
    }
  }
}
