import { Module } from '@nestjs/common';
import { StudentsModule } from '../students/students.module';
import { AppLogger } from '../common/app-logger';
import { FeesController, FeesInfoController } from './fees.controller';
import { FeesService } from './fees.service';
import { FEE_POLICY, FEE_RATE, MeritFeePolicy, StandardFeePolicy } from './fee-policy';

@Module({
  imports: [StudentsModule],
  controllers: [FeesInfoController, FeesController],
  providers: [
    FeesService,
    StandardFeePolicy,
    MeritFeePolicy,
    { provide: FEE_RATE, useValue: 5000 },
    {
      provide: FEE_POLICY,
      useFactory: (rate: number, logger: AppLogger) => {
        const selected = process.env.FEE_POLICY || 'standard';
        const policy = selected === 'merit' ? new MeritFeePolicy() : new StandardFeePolicy();
        logger.log(`Using ${policy.name} fee policy`);
        return policy;
      },
      inject: [FEE_RATE, AppLogger],
    },
    { provide: 'FEE_CALCULATOR', useExisting: FeesService },
  ],
})
export class FeesModule {}
