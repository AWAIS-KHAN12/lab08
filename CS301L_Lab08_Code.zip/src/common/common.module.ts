import { Global, Module } from '@nestjs/common';
import { AppLogger } from './app-logger';
import { APP_CONFIG } from './tokens';

@Global()
@Module({
  providers: [
    AppLogger,
    {
      provide: APP_CONFIG,
      useFactory: () => ({ storage: process.env.STORAGE || 'file' }),
    },
  ],
  exports: [AppLogger, APP_CONFIG],
})
export class CommonModule {}
