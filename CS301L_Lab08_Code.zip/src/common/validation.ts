import { BadRequestException, ValidationPipe } from '@nestjs/common';

export function createValidationPipe() {
  return new ValidationPipe({
    transform: true,
    whitelist: true,
    forbidNonWhitelisted: true,
    exceptionFactory: (errors) => {
      const details = errors.flatMap((error) =>
        Object.values(error.constraints || {}),
      );
      return new BadRequestException({
        statusCode: 400,
        error: 'Validation failed',
        details,
      });
    },
  });
}
