import { Department } from '../departments/department.enum';

export class Course {
  code: string;
  title: string;
  creditHours: number;
  instructor: string;
  department: Department;
  description?: string;
  tags?: string[];
}
