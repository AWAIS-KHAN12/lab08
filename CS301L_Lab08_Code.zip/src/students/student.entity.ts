export class Student {
  rollNumber: string;
  name: string;
  cgpa: number;
}
