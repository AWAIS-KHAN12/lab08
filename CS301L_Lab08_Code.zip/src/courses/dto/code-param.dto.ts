import { Transform } from 'class-transformer';
import { IsString, Matches } from 'class-validator';

export class CodeParamDto {
  @Transform(({ value }) => typeof value === 'string' ? value.trim().toUpperCase() : value)
  @IsString({ message: 'code must be a string' })
  @Matches(/^CS-\d{3}L?$/, { message: 'code must look like CS-301 or CS-301L' })
  code: string;
}
