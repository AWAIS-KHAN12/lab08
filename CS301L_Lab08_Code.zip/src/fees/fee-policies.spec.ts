import { MeritFeePolicy, StandardFeePolicy } from './fee-policy';

describe('Fee policies', () => {
  const standard = new StandardFeePolicy();
  const merit = new MeritFeePolicy();

  it('calculates standard fees', () => expect(standard.calculate(12, 3.8, 5000)).toBe(60000));
  it('gives 50% discount at CGPA 3.5', () => expect(merit.calculate(12, 3.5, 5000)).toBe(30000));
  it('gives 50% discount above 3.5', () => expect(merit.calculate(12, 3.8, 5000)).toBe(30000));
  it('gives 25% discount at CGPA 3.0', () => expect(merit.calculate(12, 3.0, 5000)).toBe(45000));
  it('gives 25% discount between 3.0 and 3.5', () => expect(merit.calculate(12, 3.2, 5000)).toBe(45000));
  it('gives no discount below 3.0', () => expect(merit.calculate(12, 2.9, 5000)).toBe(60000));
});
