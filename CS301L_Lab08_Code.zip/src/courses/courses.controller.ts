import { Body, Controller, Delete, Get, HttpCode, HttpStatus, Param, Patch, Post, Put, Query } from '@nestjs/common';
import { CoursesService } from './courses.service';
import { CreateCourseDto } from './dto/create-course.dto';
import { CodeParamDto } from './dto/code-param.dto';
import { QueryCourseDto } from './dto/query-course.dto';
import { PatchCourseDto, UpdateCourseDto } from './dto/update-course.dto';

@Controller('courses')
export class CoursesController {
  constructor(private readonly coursesService: CoursesService) {}

  @Get('stats')
  stats() {
    return this.coursesService.stats();
  }

  @Get()
  findAll(@Query() query: QueryCourseDto) {
    return this.coursesService.findAll(query);
  }

  @Get(':code')
  findOne(@Param() params: CodeParamDto) {
    return this.coursesService.findOne(params.code);
  }

  @Post()
  create(@Body() dto: CreateCourseDto) {
    return this.coursesService.create(dto);
  }

  @Put(':code')
  update(@Param() params: CodeParamDto, @Body() dto: UpdateCourseDto) {
    return this.coursesService.update(params.code, dto);
  }

  @Patch(':code')
  patch(@Param() params: CodeParamDto, @Body() dto: PatchCourseDto) {
    return this.coursesService.update(params.code, dto);
  }

  @Delete(':code')
  @HttpCode(HttpStatus.NO_CONTENT)
  delete(@Param() params: CodeParamDto) {
    this.coursesService.delete(params.code);
  }
}
