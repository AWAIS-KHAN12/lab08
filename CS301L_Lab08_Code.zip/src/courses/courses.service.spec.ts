import { ConflictException, NotFoundException } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import { AppLogger } from '../common/app-logger';
import { Department } from '../departments/department.enum';
import { CoursesService } from './courses.service';
import { CreditService } from './credit.service';
import { COURSE_STORE, InMemoryCourseStore } from './store/course-store';

describe('CoursesService', () => {
  let service: CoursesService;
  let logger: { log: jest.Mock };
  const seed = [{
    code: 'CS-301', title: 'Web Development', creditHours: 3,
    instructor: 'Dr. Hamza', department: Department.ComputerScience,
  }];

  beforeEach(async () => {
    logger = { log: jest.fn() };
    const module = await Test.createTestingModule({
      providers: [
        CoursesService,
        CreditService,
        { provide: COURSE_STORE, useValue: new InMemoryCourseStore(seed) },
        { provide: AppLogger, useValue: logger },
      ],
    }).compile();
    service = module.get(CoursesService);
  });

  it('lists courses', () => expect(service.findAll()).toHaveLength(1));
  it('finds a course', () => expect(service.findOne('CS-301').title).toBe('Web Development'));
  it('throws for unknown course', () => expect(() => service.findOne('CS-999')).toThrow(NotFoundException));
  it('creates a course and logs it', () => {
    const result = service.create({
      code: 'CS-420', title: 'Compilers', creditHours: 3,
      instructor: 'Dr. Hamza Rauf', department: Department.ComputerScience,
    });
    expect(result.code).toBe('CS-420');
    expect(logger.log).toHaveBeenCalledWith('Created course CS-420');
  });
  it('rejects duplicate course codes', () => {
    expect(() => service.create({
      code: 'CS-301', title: 'Duplicate', creditHours: 3,
      instructor: 'Dr. Hamza', department: Department.ComputerScience,
    })).toThrow(ConflictException);
  });
  it('deletes a course and logs it', () => {
    service.delete('CS-301');
    expect(() => service.findOne('CS-301')).toThrow(NotFoundException);
    expect(logger.log).toHaveBeenCalledWith('Deleted course CS-301');
  });
  it('calculates statistics', () => expect(service.stats()).toEqual({
    totalCourses: 1, totalCredits: 3, overloaded: false,
  }));
});
