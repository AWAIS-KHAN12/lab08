# Lab 08 — Validation Results

Run the API and copy the actual status codes and response bodies from Postman into this document. Do not treat expected results as observed results until the requests have been run.

| Request | Expected result from task sheet | Actual result |
|---|---|---|
| Valid POST /api/courses | 201; transformed values | To be recorded after running |
| POST with creditHours as text | 400 | To be recorded after running |
| Invalid code/title/creditHours | 400 | To be recorded after running |
| POST with six tags | 400 | To be recorded after running |
| GET /api/courses?minCredits=abc | 400 | To be recorded after running |
| GET /api/courses?sort=title | 400 | To be recorded after running |
| GET /api/courses/abc | 400 | To be recorded after running |
| GET /api/fees/BSCS-023 without creditHours | 400 | To be recorded after running |
| PATCH with code property | 400 | To be recorded after running |
| POST with isAdmin property | 400 | To be recorded after running |

## Decorator notes
- `@Matches` validates the course-code pattern.
- `@MinLength` validates the minimum title and instructor length.
- `@IsInt`, `@Min`, and `@Max` validate credit hours.
- `@ArrayMaxSize` limits the number of tags.
- `@IsEnum` validates the department.
- `@IsIn` restricts sorting to `creditHours` and order to `asc` or `desc`.
- `whitelist` and `forbidNonWhitelisted` reject properties not declared by the DTO.
- `@Type(() => Number)` converts query values before numeric validation.
