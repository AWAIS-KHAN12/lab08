# Lab 08 — Short Answers

### (a) Why can an interface not be an injection token?
A TypeScript interface is only used during compilation and is removed from the JavaScript output. NestJS needs a runtime value to identify a dependency, so we use a class, string token, Symbol token, or another supported runtime token.

### (b) What does it mean that a provider is a singleton?
A singleton provider is normally created once for a module's provider scope and the same instance is reused when it is injected. This avoids creating a new service instance for every injection.

### (c) What must you write so that OtherModule can use CoursesService?
`CoursesModule` must include `CoursesService` in its `exports` array. `OtherModule` must then import `CoursesModule` in its `imports` array.
