import { Module } from '@nestjs/common';
import * as fs from 'fs';
import * as path from 'path';
import { AppLogger } from '../common/app-logger';
import { APP_CONFIG } from '../common/tokens';
import { CoursesController } from './courses.controller';
import { CoursesService } from './courses.service';
import { CreditService } from './credit.service';
import { COURSE_STORE, InMemoryCourseStore, JsonFileCourseStore } from './store/course-store';

@Module({
  controllers: [CoursesController],
  providers: [
    CoursesService,
    CreditService,
    {
      provide: COURSE_STORE,
      useFactory: (config: { storage: string }, logger: AppLogger) => {
        if (config.storage === 'memory') {
          logger.log('Using memory storage');
          const file = path.join(process.cwd(), 'src/courses/data/courses.json');
          const courses = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
          return new InMemoryCourseStore(courses);
        }
        logger.log('Using file storage');
        return new JsonFileCourseStore();
      },
      inject: [APP_CONFIG, AppLogger],
    },
  ],
  exports: [CoursesService],
})
export class CoursesModule {}
