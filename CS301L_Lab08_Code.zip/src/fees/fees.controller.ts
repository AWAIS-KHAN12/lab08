import { Controller, Get, Inject, Param, Query } from '@nestjs/common';
import { FeeQueryDto } from './dto/fee-query.dto';
import { FeesService } from './fees.service';

@Controller('fees')
export class FeesController {
  constructor(private readonly feesService: FeesService) {}

  @Get(':rollNumber')
  calculate(@Param('rollNumber') rollNumber: string, @Query() query: FeeQueryDto) {
    return this.feesService.calculate(rollNumber, query.creditHours);
  }
}

@Controller('fees')
export class FeesInfoController {
  constructor(@Inject('FEE_CALCULATOR') private readonly calculator: FeesService) {}

  @Get('info')
  getPolicyInfo() {
    return this.calculator.info();
  }
}
