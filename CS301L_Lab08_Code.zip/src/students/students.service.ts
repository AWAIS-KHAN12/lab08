import { Injectable, NotFoundException } from '@nestjs/common';
import { Student } from './student.entity';

@Injectable()
export class StudentsService {
  private readonly students: Student[] = [
    { rollNumber: 'BSCS-023', name: 'Sara Ahmed', cgpa: 3.8 },
    { rollNumber: 'BSCS-024', name: 'Ali Raza', cgpa: 3.2 },
    { rollNumber: 'BSCS-025', name: 'Hina Malik', cgpa: 2.7 },
  ];

  findAll(): Student[] {
    return [...this.students];
  }

  findOne(rollNumber: string): Student {
    const student = this.students.find(
      (item) => item.rollNumber.toUpperCase() === rollNumber.toUpperCase(),
    );
    if (!student) throw new NotFoundException('Student not found');
    return student;
  }
}
