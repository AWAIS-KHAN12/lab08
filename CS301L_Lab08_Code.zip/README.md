# CS-301L Lab 08 — NestJS

This project demonstrates NestJS dependency injection, custom providers, fee policies, DTO transformation, validation, and tests.

## Install and run

```bash
npm install
npm run start:dev
```

The API uses the `/api` prefix and normally runs at `http://localhost:3000`.

## Environment variables

### Storage
File storage is the default:

```bash
STORAGE=file npm run start:dev
```

Memory storage:

```bash
STORAGE=memory npm run start:dev
```

In Windows PowerShell, set variables first:

```powershell
$env:STORAGE="memory"
npm run start:dev
```

### File logging

```powershell
$env:LOG_TO_FILE="true"
npm run start:dev
```

When enabled, log messages are appended to `logs/app.log`.

### Fee policy

Standard fee calculation:

```powershell
$env:FEE_POLICY="standard"
npm run start:dev
```

Merit discounts:

```powershell
$env:FEE_POLICY="merit"
npm run start:dev
```

The merit policy gives 50% off for CGPA 3.5 or higher, 25% off for CGPA 3.0 to below 3.5, and no discount below 3.0.

## Main endpoints

- `GET /api/students`
- `GET /api/students/:rollNumber`
- `GET /api/courses`
- `GET /api/courses/stats`
- `GET /api/courses/:code`
- `POST /api/courses`
- `PUT /api/courses/:code`
- `PATCH /api/courses/:code`
- `DELETE /api/courses/:code`
- `GET /api/fees/info`
- `GET /api/fees/:rollNumber?creditHours=12`

## Tests

```bash
npm test
npm run test:e2e
npm run build
```

## Postman

Import `postman/Lab08_Tasks.postman_collection.json`, set `baseUrl` to `http://localhost:3000/api`, and run the collection twice. Save screenshots of the actual passing test results in `screenshots/`.

## Note
This is a student-level implementation based on the supplied task sheet. Review the code and run the tests in your local environment before submission. `RESULTS.md` and screenshots must contain genuine results from your own run.
