import { Controller, Get, Param } from '@nestjs/common';
import { StudentsService } from './students.service';

@Controller('students')
export class StudentsController {
  constructor(private readonly studentsService: StudentsService) {}

  @Get()
  findAll() {
    return this.studentsService.findAll();
  }

  @Get(':rollNumber')
  findOne(@Param('rollNumber') rollNumber: string) {
    return this.studentsService.findOne(rollNumber);
  }
}
