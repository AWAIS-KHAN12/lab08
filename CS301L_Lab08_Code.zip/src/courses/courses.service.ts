import { ConflictException, Inject, Injectable, NotFoundException } from '@nestjs/common';
import { AppLogger } from '../common/app-logger';
import { Course } from './course.entity';
import { CreditService } from './credit.service';
import { COURSE_STORE, CourseStore } from './store/course-store';
import { CreateCourseDto } from './dto/create-course.dto';
import { UpdateCourseDto, PatchCourseDto } from './dto/update-course.dto';
import { QueryCourseDto } from './dto/query-course.dto';

@Injectable()
export class CoursesService {
  constructor(
    @Inject(COURSE_STORE) private readonly store: CourseStore,
    private readonly creditService: CreditService,
    private readonly logger: AppLogger,
  ) {}

  findAll(query: QueryCourseDto = {}): Course[] {
    let courses = this.store.readAll();
    if (query.search) {
      const term = query.search.toLowerCase();
      courses = courses.filter((course) =>
        `${course.code} ${course.title} ${course.instructor}`.toLowerCase().includes(term),
      );
    }
    if (query.department) courses = courses.filter((course) => course.department === query.department);
    if (query.minCredits !== undefined) courses = courses.filter((course) => course.creditHours >= query.minCredits);
    if (query.sort === 'creditHours') {
      courses.sort((a, b) => query.order === 'desc' ? b.creditHours - a.creditHours : a.creditHours - b.creditHours);
    }
    if (query.limit !== undefined) courses = courses.slice(0, query.limit);
    return courses;
  }

  stats() {
    const courses = this.store.readAll();
    const totalCredits = this.creditService.totalCredits(courses);
    return {
      totalCourses: courses.length,
      totalCredits,
      overloaded: this.creditService.isOverloaded(totalCredits),
    };
  }

  findOne(code: string): Course {
    const course = this.store.readAll().find((item) => item.code === code);
    if (!course) throw new NotFoundException('Course not found');
    return course;
  }

  create(dto: CreateCourseDto): Course {
    const courses = this.store.readAll();
    if (courses.some((item) => item.code === dto.code)) {
      throw new ConflictException('Course code already exists');
    }
    const course: Course = { ...dto };
    courses.push(course);
    this.store.writeAll(courses);
    this.logger.log(`Created course ${course.code}`);
    return course;
  }

  update(code: string, dto: UpdateCourseDto | PatchCourseDto): Course {
    const courses = this.store.readAll();
    const index = courses.findIndex((item) => item.code === code);
    if (index === -1) throw new NotFoundException('Course not found');
    courses[index] = { ...courses[index], ...dto, code };
    this.store.writeAll(courses);
    return courses[index];
  }

  delete(code: string): void {
    const courses = this.store.readAll();
    const index = courses.findIndex((item) => item.code === code);
    if (index === -1) throw new NotFoundException('Course not found');
    courses.splice(index, 1);
    this.store.writeAll(courses);
    this.logger.log(`Deleted course ${code}`);
  }
}
