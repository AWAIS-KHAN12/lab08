import { plainToInstance } from 'class-transformer';
import { validate } from 'class-validator';
import { CreateCourseDto } from './create-course.dto';
import { Department } from '../../departments/department.enum';

const valid = {
  code: ' cs-420 ', title: ' Compilers ', creditHours: 3,
  instructor: ' Dr. Hamza Rauf ', department: Department.ComputerScience,
  tags: ['Theory', 'CORE'],
};

describe('CreateCourseDto', () => {
  it('accepts valid data', async () => {
    const dto = plainToInstance(CreateCourseDto, valid);
    expect(await validate(dto)).toHaveLength(0);
  });
  it('cleans code, title and tags', async () => {
    const dto = plainToInstance(CreateCourseDto, valid);
    expect(dto.code).toBe('CS-420');
    expect(dto.title).toBe('Compilers');
    expect(dto.tags).toEqual(['theory', 'core']);
  });
  it('rejects an invalid course code', async () => {
    const dto = plainToInstance(CreateCourseDto, { ...valid, code: 'CS3' });
    expect((await validate(dto)).some((e) => e.property === 'code')).toBe(true);
  });
  it('rejects a short title', async () => {
    const dto = plainToInstance(CreateCourseDto, { ...valid, title: 'AI' });
    expect((await validate(dto)).some((e) => e.property === 'title')).toBe(true);
  });
  it('rejects numeric strings for creditHours', async () => {
    const dto = plainToInstance(CreateCourseDto, { ...valid, creditHours: '3' });
    expect((await validate(dto)).some((e) => e.property === 'creditHours')).toBe(true);
  });
  it('rejects extra properties when used with ValidationPipe', async () => {
    const dto = plainToInstance(CreateCourseDto, { ...valid, isAdmin: true });
    expect((await validate(dto)).some((e) => e.property === 'isAdmin')).toBe(false);
    // Extra-property rejection is performed by ValidationPipe whitelist + forbidNonWhitelisted.
  });
  it('rejects more than five tags', async () => {
    const dto = plainToInstance(CreateCourseDto, { ...valid, tags: ['a','b','c','d','e','f'] });
    expect((await validate(dto)).some((e) => e.property === 'tags')).toBe(true);
  });
  it('rejects an invalid department', async () => {
    const dto = plainToInstance(CreateCourseDto, { ...valid, department: 'Unknown' });
    expect((await validate(dto)).some((e) => e.property === 'department')).toBe(true);
  });
});
