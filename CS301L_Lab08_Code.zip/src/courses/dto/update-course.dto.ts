import { PartialType, OmitType } from '@nestjs/mapped-types';
import { CreateCourseDto } from './create-course.dto';

export class UpdateCourseDto extends PartialType(
  OmitType(CreateCourseDto, ['code'] as const),
) {}

export class PatchCourseDto extends PartialType(UpdateCourseDto) {}
