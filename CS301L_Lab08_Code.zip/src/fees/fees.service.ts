import { Inject, Injectable } from '@nestjs/common';
import { StudentsService } from '../students/students.service';
import { FEE_POLICY, FEE_RATE, FeePolicy } from './fee-policy';

@Injectable()
export class FeesService {
  constructor(
    @Inject(FEE_POLICY) private readonly feePolicy: FeePolicy,
    @Inject(FEE_RATE) private readonly ratePerCreditHour: number,
    private readonly studentsService: StudentsService,
  ) {}

  calculate(rollNumber: string, creditHours: number) {
    const student = this.studentsService.findOne(rollNumber);
    return {
      rollNumber: student.rollNumber,
      name: student.name,
      cgpa: student.cgpa,
      creditHours,
      policy: this.feePolicy.name,
      ratePerCreditHour: this.ratePerCreditHour,
      total: this.feePolicy.calculate(creditHours, student.cgpa, this.ratePerCreditHour),
    };
  }

  info() {
    return {
      policy: this.feePolicy.name,
      ratePerCreditHour: this.ratePerCreditHour,
    };
  }
}
